package com.example;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/processForm")
public class ProcessFormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String add = request.getParameter("add");
       

        // Process form data (e.g., save to database, send email, etc.)

        // Set response content type
        response.setContentType("text/html");

        // Generate response
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Form Submitted Successfully</h2>");
        response.getWriter().println("<p>Name: " + name + "</p>");
        response.getWriter().println("<p>Email: " + email + "</p>");
        response.getWriter().println("<p>Address: " + add + "</p>");
        response.getWriter().println("</body></html>");
    }
}
